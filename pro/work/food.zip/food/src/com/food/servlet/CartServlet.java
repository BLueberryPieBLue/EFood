package com.food.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.beans.Dish;


public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		List<Dish> cart=null;
		boolean purFlag=true;
		HttpSession session =request.getSession(false);
		if(session==null) {
			purFlag=false;
		}else {
			cart=(List) session.getAttribute("cart");
			if(cart==null) {
				purFlag=false;
			}
		}
		if (!purFlag) {
			out.write("Sorry,you don't buy anything");
		}else {
			out.write("dishes:<br>ID	菜品名称	      菜品单价<br>");
			double price=0;
			for(Dish dish:cart) {
				out.write(dish+"<br>");
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
